import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TamagotchiSpielfigurPage } from './tamagotchi-spielfigur';

@NgModule({
  declarations: [
    TamagotchiSpielfigurPage,
  ],
  imports: [
    IonicPageModule.forChild(TamagotchiSpielfigurPage),
  ],
})
export class TamagotchiSpielfigurPageModule {}
